var win = Ti.UI.createWindow({
    layout: 'vertical',
    backgroundColor: 'white'
});

var Push = require('ti.push');
Push.addEventListener('callback', function (evt) {
    alert(evt.payload);
});
Push.addEventListener('trayClickLaunchedApp', function (evt) {
    Ti.API.info('Tray Click Launched App (app was not running)');
});
Push.addEventListener('trayClickFocusedApp', function (evt) {
    Ti.API.info('Tray Click Focused App (app was already running)');
});

Ti.API.info('Device Token: ' + Push.deviceToken);

/*
 Push can be enabled or disabled.
 */
var enablePush = Ti.UI.createButton({
    top: '10dp', width: '320dp', height: '40dp'
});
enablePush.addEventListener('click', function () {
    enablePush.title = Push.enabled ? 'Disabling...' : 'Enabling...';
    Push.enabled = !Push.enabled;
    // NOTE: Push.enabled takes a moment to update after you change its value.
    setTimeout(syncButtons, 500);
});
win.add(enablePush);

/*
 Whether or not to show a tray notification.
 */
var showTrayNotification = Ti.UI.createButton({
    top: '10dp', width: '320dp', height: '40dp'
});
showTrayNotification.addEventListener('click', function () {
    Push.showTrayNotification = !Push.showTrayNotification;
    syncButtons();
});
win.add(showTrayNotification);

/*
 Whether or not clicking a tray notification focuses the app.
 */
var showAppOnTrayClick = Ti.UI.createButton({
    top: '10dp', width: '320dp', height: '40dp'
});
showAppOnTrayClick.addEventListener('click', function () {
    Push.showAppOnTrayClick = !Push.showAppOnTrayClick;
    syncButtons();
});
win.add(showAppOnTrayClick);

/*
 Whether or not tray notifications are shown when the app is in the foreground.
 */
var showTrayNotificationsWhenFocused = Ti.UI.createButton({
    top: '10dp', width: '320dp', height: '40dp'
});
showTrayNotificationsWhenFocused.addEventListener('click', function () {
    Push.showTrayNotificationsWhenFocused = !Push.showTrayNotificationsWhenFocused;
    syncButtons();
});
win.add(showTrayNotificationsWhenFocused);

/*
 Whether or not receiving a push immediately brings the application to the foreground.
 */
var focusAppOnPush = Ti.UI.createButton({
    top: '10dp', width: '320dp', height: '40dp'
});
focusAppOnPush.addEventListener('click', function () {
    Push.focusAppOnPush = !Push.focusAppOnPush;
    syncButtons();
});
win.add(focusAppOnPush);

function syncButtons() {
    enablePush.title = Push.enabled ? 'Push Enabled' : 'Push Disabled';
    showAppOnTrayClick.title = Push.showAppOnTrayClick ? 'Tray Click Shows App' : 'Tray Click Does Nothing';
    showTrayNotification.title = Push.showTrayNotification ? 'Show in Tray' : 'Do Not Show in Tray';
    focusAppOnPush.title = Push.focusAppOnPush ? 'Push Focuses App' : 'Push Doesn\'t Focus App';
    showTrayNotificationsWhenFocused.title = Push.showTrayNotificationsWhenFocused ? 'Show Trays when Focused' : 'Hide Trays when Focused';
}

syncButtons();
win.open();